#include "window.h"

namespace sparky { namespace graphics {


    void window_resize(GLFWwindow *window, int width, int height);

    Window::Window(const char *title, int width, int height)
    {
        m_Title = title;
        m_Width = width;
        m_Height = height;
        if (!init())
        {
            glfwTerminate();
        }
        for (int i=0; i < MAX_KEYS; i++)
        {
            m_Keys[i] = false;
        }
        for (int i=0; i < MAX_BUTTONS; i++)
        {
            m_MouseButtons[i] = false;
        }
   }

    Window::~Window()
    {
        glfwTerminate();
    }

    bool Window::init()
    {
        /* Initialize the library */
        if (!glfwInit())
        {
            cerr << "Error Initializing GLFW library." << endl;
            return false;
        }

        m_Window = glfwCreateWindow(m_Width, m_Height, m_Title, NULL, NULL);

        if (!m_Window)
        {
            glfwTerminate();
            cerr << "Failed to create GLFW window!" << endl;
            return false;
        }

        glfwMakeContextCurrent(m_Window);
        glfwSetWindowUserPointer(m_Window, this);

        // Setting up our callback functions
        glfwSetWindowSizeCallback(m_Window, window_resize);
		glfwSetKeyCallback(m_Window, key_callback);
		glfwSetMouseButtonCallback(m_Window, mouse_button_callback);
        glfwSetCursorPosCallback(m_Window, cursor_position_callback);

        if (glewInit() != GLEW_OK)
        {
            cerr << "Could not initialize GLEW!" << endl;
            return false;
        }
        return true;
    }

    bool Window::closed() const
    {
        return glfwWindowShouldClose(m_Window) == 1;
    }
    void Window::clear() const
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
    void Window::update()
    {
        glfwPollEvents();
//        glfwGetFramebufferSize(m_Window, &m_Width, &m_Height);
        glfwSwapBuffers(m_Window);
    }

    void window_resize(GLFWwindow *window, int width, int height)
    {
         glViewport(0, 0, width, height);
    }

	void Window::setKey(unsigned int keyCode, bool val)
	{
		if (keyCode >= 0 && keyCode < MAX_KEYS)
		{
			m_Keys[keyCode] = val;
		}
	}

	bool Window::isKeyPressed(unsigned int keyCode) const
	{
		if (keyCode >= 0 && keyCode < MAX_KEYS)
		{
			return m_Keys[keyCode];
		}
		// TODO: Log this!
		return false;
	}

    void Window::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
    {
        Window* win = (Window*) glfwGetWindowUserPointer(window);
        win->setKey(key, action != GLFW_RELEASE);
    }

    void Window::mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
    {
        Window* win = (Window*) glfwGetWindowUserPointer(window);
        win->setMouseButton(button, action != GLFW_RELEASE);
    }

	void Window::setMousePosition(double x, double y)
	{
		mx = x;
		my = y;
	}

	void Window::getMousePosition(double& x, double& y) const
	{
		x = mx;
		y = my;
	}

    void Window::cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
    {
        Window* win = (Window*) glfwGetWindowUserPointer(window);
        win->setMousePosition(xpos, ypos);
    }


    bool Window::isMouseButtonPressed(unsigned int button) const
    {
        if (button >=0 && button < MAX_BUTTONS)
        {
            return m_MouseButtons[button];
        }
        // TODO: Log this!
        return false;
    }



    void Window::setMouseButton(unsigned int button, bool val)
    {
        if (button >= 0 && button < MAX_BUTTONS)
        {
            m_MouseButtons[button] = val;
        }
    }


} }

