#ifndef MATHS_H_INCLUDED
#define MATHS_H_INCLUDED

#include "vec2.h"
#include "vec3.h"
#include "vec4.h"

#endif // MATHS_H_INCLUDED
