#ifndef VEC4_H_INCLUDED
#define VEC4_H_INCLUDED

#include <iostream>
using namespace std;

namespace sparky { namespace maths {

    struct vec4{
        float x, y, z, w;

        vec4();
        vec4(const float&x, const float&y, const float&z, const float&w);

        vec4& add(const vec4& other);
        vec4& subtract(const vec4& other);
        vec4& multiply(const vec4& other);
        vec4& divide(const vec4& other);

        vec4 operator+(const vec4& other) const;
        vec4 operator-(const vec4& other) const;
        vec4 operator*(const vec4& other) const;
        vec4 operator/(const vec4& other) const;

        vec4& operator+=(const vec4& other);
        vec4& operator-=(const vec4& other);
        vec4& operator*=(const vec4& other);
        vec4& operator/=(const vec4& other);

		bool operator==(const vec4& other);
		bool operator!=(const vec4& other);

		friend ostream& operator<<(ostream& stream, const vec4& vector);

    };

}}

#endif // VEC4_H_INCLUDED
