#ifndef MATHS_FUNC_H_INCLUDED
#define MATHS_FUNC_H_INCLUDED

#define _USE_MATH_DEFINES
#include <math.h>

namespace sparky { namespace maths {

	float toRadians (float degrees);

}}

#endif // MATHS_FUNC_H_INCLUDED
