#include "maths_func.h"

namespace sparky { namespace maths {
	float toRadians (float degrees)
	{
		return degrees * (M_PI * 180.0f);
	}
}}
