#include "UnitTest++.h"
#include "../src/maths/vec4.h"

using namespace sparky;
using namespace maths;
namespace
{
	TEST(Testvec4DefaultXArgument)
	{
		const vec4 myvec4;
		CHECK_EQUAL(myvec4.x, 0);
	}

	TEST(Testvec4DefaultYArgument)
	{
		const vec4 myvec4;
		CHECK_EQUAL(myvec4.y, 0);
	}

	TEST(Testvec4DefaultZArgument)
	{
		const vec4 myvec4;
		CHECK_EQUAL(myvec4.z, 0);
	}

	TEST(Testvec4DefaultWArgument)
	{
		const vec4 myvec4;
		CHECK_EQUAL(myvec4.w, 0);
	}

	TEST(Testvec4XArgument)
	{
		const vec4 myvec4(2.0f, 5.0f, 8.0, 3.0);
		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
	}
	TEST(Testvec4YArgument)
	{
		const vec4 myvec4(2.0f, 5.0f, 8.0, 3.0);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
	}
	TEST(Testvec4ZArgument)
	{
		const vec4 myvec4(2.0f, 5.0f, 8.0, 3.0);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
	}

	TEST(Testvec4WArgument)
	{
		const vec4 myvec4(2.0f, 5.0f, 8.0, 3.0);
		CHECK_CLOSE(myvec4.w, 3.0f, 0.01f);
	}
	TEST(Testvec4Add)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1.add(myvec4);
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 9.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 8.0f, 0.01f);
	}

	TEST(Testvec4Subtract)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1.subtract(myvec4);
		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, -7.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 0.0f, 0.01f);
	}

	TEST(Testvec4Multiply)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1.multiply(myvec4);
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 16.0f, 0.01f);
	}

	TEST(Testvec4Divide)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1.divide(myvec4);
		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0f/8.0f;
		float wExpected = 4.0f/4.0f;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);
		CHECK_CLOSE(myVec1.z, zExpected, 0.01f);
		CHECK_CLOSE(myVec1.w, wExpected, 0.01f);
	}
	// the operators
	TEST(Testvec4AddOperator1)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		vec4 result = myVec1 + myvec4;
		CHECK_CLOSE(result.x, 5.0f, 0.01f);
		CHECK_CLOSE(result.y, 8.0f, 0.01f);
		CHECK_CLOSE(result.z, 9.0f, 0.01f);
		CHECK_CLOSE(result.w, 8.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 4.0f, 0.01f);

		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4AddOperator2)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1 += myvec4;
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 9.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 8.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4SubtractOperator1)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);

		vec4 result = myVec1 - myvec4;
		CHECK_CLOSE(result.x, 1.0f, 0.01f);
		CHECK_CLOSE(result.y, -2.0f, 0.01f);
		CHECK_CLOSE(result.z, -7.0f, 0.01f);
		CHECK_CLOSE(result.w, 0.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 4.0f, 0.01f);

		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4SubtractOperator2)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1 -= myvec4;

		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, -7.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 0.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4MultiplyOperator1)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		vec4 result = myVec1 * myvec4;
		CHECK_CLOSE(result.x, 6.0f, 0.01f);
		CHECK_CLOSE(result.y, 15.0f, 0.01f);
		CHECK_CLOSE(result.z, 8.0f, 0.01f);
		CHECK_CLOSE(result.w, 16.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 4.0f, 0.01f);

		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4MultiplyOperator2)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);

		myVec1 *= myvec4;
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 16.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4DivideOperator1)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		vec4 result = myVec1 / myvec4;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0/8.0f;
		float wExpected = 4.0f/4.0f;
		CHECK_CLOSE(result.x, xExpected, 0.01f);
		CHECK_CLOSE(result.y, yExpected, 0.01f);
		CHECK_CLOSE(result.z, zExpected, 0.01f);
		CHECK_CLOSE(result.w, wExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 4.0f, 0.01f);

		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4DivideOperator2)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		const vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1 /= myvec4;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0/8.0f;
		float wExpected = 4.0/4.0;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);
		CHECK_CLOSE(myVec1.z, zExpected, 0.01f);
		CHECK_CLOSE(myVec1.w, wExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec4.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec4.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec4.z, 8.0f, 0.01f);
		CHECK_CLOSE(myvec4.w, 4.0f, 0.01f);
	}

	TEST(Testvec4Assignment)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1 = myvec4;

		CHECK_CLOSE(myVec1.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.w, 4.0f, 0.01f);
	}

	TEST(Testvec4Equality1)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);
		myVec1 = myvec4;

		CHECK_EQUAL(myVec1 == myvec4, true);
	}

	TEST(Testvec4Equality2)
	{
		vec4 myVec1(3.0f, 3.0f, 1.0f, 4.0f);
		vec4 myvec4(2.0f, 5.0f, 8.0f, 4.0f);

		CHECK_EQUAL(myVec1 != myvec4, true);
	}
}
