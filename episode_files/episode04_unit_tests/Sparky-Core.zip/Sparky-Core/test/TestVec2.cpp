#include "UnitTest++.h"
#include "../src/maths/vec2.h"

using namespace sparky;
using namespace maths;
namespace
{
	TEST(TestDefaultXArgument)
	{
		const vec2 myVec2;
		CHECK_EQUAL(myVec2.x, 0);
	}
	TEST(TestDefaultYArgument)
	{
		const vec2 myVec2;
		CHECK_EQUAL(myVec2.y, 0);
	}
	TEST(TestXArgument)
	{
		const vec2 myVec2(2.0f, 5.0f);
		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
	}
	TEST(TestYArgument)
	{
		const vec2 myVec2(2.0f, 5.0f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestAdd)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1.add(myVec2);
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
	}

	TEST(TestSubtract)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1.subtract(myVec2);
		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);
	}

	TEST(TestMultiply)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1.multiply(myVec2);
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);
	}

	TEST(TestDivide)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1.divide(myVec2);
		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);
	}
	// the operators
	TEST(TestAddOperator1)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		vec2 result = myVec1 + myVec2;
		CHECK_CLOSE(result.x, 5.0f, 0.01f);
		CHECK_CLOSE(result.y, 8.0f, 0.01f);
		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);

		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestAddOperator2)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1 += myVec2;
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
		// make sure vectors involved not changed

		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestSubtractOperator1)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		vec2 result = myVec1 - myVec2;
		CHECK_CLOSE(result.x, 1.0f, 0.01f);
		CHECK_CLOSE(result.y, -2.0f, 0.01f);
		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);

		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestSubtractOperator2)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1 -= myVec2;

		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestMultiplyOperator1)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		vec2 result = myVec1 * myVec2;
		CHECK_CLOSE(result.x, 6.0f, 0.01f);
		CHECK_CLOSE(result.y, 15.0f, 0.01f);
		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);

		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestMultiplyOperator2)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);

		myVec1 *= myVec2;
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestDivideOperator1)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		vec2 result = myVec1 / myVec2;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		CHECK_CLOSE(result.x, xExpected, 0.01f);
		CHECK_CLOSE(result.y, yExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);

		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestDivideOperator2)
	{
		vec2 myVec1(3.0f, 3.0f);
		const vec2 myVec2(2.0f, 5.0f);
		myVec1 /= myVec2;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec2.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec2.y, 5.0f, 0.01f);
	}

	TEST(TestAssignment)
	{
		vec2 myVec1(3.0f, 3.0f);
		vec2 myVec2(2.0f, 5.0f);
		myVec1 = myVec2;

		CHECK_CLOSE(myVec1.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 5.0f, 0.01f);
	}

	TEST(TestEquality1)
	{
		vec2 myVec1(3.0f, 3.0f);
		vec2 myVec2(2.0f, 5.0f);
		myVec1 = myVec2;

		CHECK_EQUAL(myVec1 == myVec2, true);
	}

	TEST(TestEquality2)
	{
		vec2 myVec1(3.0f, 3.0f);
		vec2 myVec2(2.0f, 5.0f);

		CHECK_EQUAL(myVec1 != myVec2, true);
	}
}
