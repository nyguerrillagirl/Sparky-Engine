#include "UnitTest++.h"
#include "../src/maths/vec3.h"

using namespace sparky;
using namespace maths;
namespace
{
	TEST(TestVec3DefaultXArgument)
	{
		const vec3 myvec3;
		CHECK_EQUAL(myvec3.x, 0);
	}

	TEST(TestVec3DefaultYArgument)
	{
		const vec3 myvec3;
		CHECK_EQUAL(myvec3.y, 0);
	}

	TEST(TestVec3DefaultZArgument)
	{
		const vec3 myvec3;
		CHECK_EQUAL(myvec3.z, 0);
	}

	TEST(TestVec3XArgument)
	{
		const vec3 myvec3(2.0f, 5.0f, 8.0);
		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
	}
	TEST(TestVec3YArgument)
	{
		const vec3 myvec3(2.0f, 5.0f, 8.0);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
	}
	TEST(TestVec3ZArgument)
	{
		const vec3 myvec3(2.0f, 5.0f, 8.0);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3Add)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1.add(myvec3);
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 9.0f, 0.01f);
	}

	TEST(TestVec3Subtract)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1.subtract(myvec3);
		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, -7.0f, 0.01f);
	}

	TEST(TestVec3Multiply)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1.multiply(myvec3);
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);
	}

	TEST(TestVec3Divide)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1.divide(myvec3);
		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0f/8.0f;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);
		CHECK_CLOSE(myVec1.z, zExpected, 0.01f);
	}
	// the operators
	TEST(TestVec3AddOperator1)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		vec3 result = myVec1 + myvec3;
		CHECK_CLOSE(result.x, 5.0f, 0.01f);
		CHECK_CLOSE(result.y, 8.0f, 0.01f);
		CHECK_CLOSE(result.z, 9.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);

		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3AddOperator2)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1 += myvec3;
		CHECK_CLOSE(myVec1.x, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 8.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 9.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3SubtractOperator1)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);

		vec3 result = myVec1 - myvec3;
		CHECK_CLOSE(result.x, 1.0f, 0.01f);
		CHECK_CLOSE(result.y, -2.0f, 0.01f);
		CHECK_CLOSE(result.z, -7.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);

		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3SubtractOperator2)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1 -= myvec3;

		CHECK_CLOSE(myVec1.x, 1.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, -2.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, -7.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3MultiplyOperator1)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		vec3 result = myVec1 * myvec3;
		CHECK_CLOSE(result.x, 6.0f, 0.01f);
		CHECK_CLOSE(result.y, 15.0f, 0.01f);
		CHECK_CLOSE(result.z, 8.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);

		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3MultiplyOperator2)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);

		myVec1 *= myvec3;
		CHECK_CLOSE(myVec1.x, 6.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 15.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3DivideOperator1)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		vec3 result = myVec1 / myvec3;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0/8.0f;

		CHECK_CLOSE(result.x, xExpected, 0.01f);
		CHECK_CLOSE(result.y, yExpected, 0.01f);
		CHECK_CLOSE(result.z, zExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myVec1.x, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 3.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 1.0f, 0.01f);

		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3DivideOperator2)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		const vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1 /= myvec3;

		float xExpected = 3.0f/2.0f;
		float yExpected = 3.0f/5.0f;
		float zExpected = 1.0/8.0f;
		CHECK_CLOSE(myVec1.x, xExpected, 0.01f);
		CHECK_CLOSE(myVec1.y, yExpected, 0.01f);
		CHECK_CLOSE(myVec1.z, zExpected, 0.01f);

		// make sure vectors involved not changed
		CHECK_CLOSE(myvec3.x, 2.0f, 0.01f);
		CHECK_CLOSE(myvec3.y, 5.0f, 0.01f);
		CHECK_CLOSE(myvec3.z, 8.0f, 0.01f);
	}

	TEST(TestVec3Assignment)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1 = myvec3;

		CHECK_CLOSE(myVec1.x, 2.0f, 0.01f);
		CHECK_CLOSE(myVec1.y, 5.0f, 0.01f);
		CHECK_CLOSE(myVec1.z, 8.0f, 0.01f);
	}

	TEST(TestVec3Equality1)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		vec3 myvec3(2.0f, 5.0f, 8.0f);
		myVec1 = myvec3;

		CHECK_EQUAL(myVec1 == myvec3, true);
	}

	TEST(TestVec3Equality2)
	{
		vec3 myVec1(3.0f, 3.0f, 1.0f);
		vec3 myvec3(2.0f, 5.0f, 8.0f);

		CHECK_EQUAL(myVec1 != myvec3, true);
	}
}
