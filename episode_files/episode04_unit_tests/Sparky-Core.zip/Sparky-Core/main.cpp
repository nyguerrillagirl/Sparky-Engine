
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "src/graphics/window.h"
#include "src/maths/maths.h"

using namespace std;

int main(void)
{
    using namespace sparky;
    using namespace graphics;
	using namespace maths;

    Window window("Sparky", 960, 540);
    glClearColor(0.2f, 0.3f, 0.8f, 1.0f);

    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

	mat4 position = mat4::translation(vec3(2,3,4));
	position *= mat4::identity();
	//vector1 /= vector2;
    cout << "OpenGL version: " << glGetString(GL_VERSION) << endl;
    while (!window.closed())
    {
        window.clear();
		/*
		if (window.isKeyPressed(GLFW_KEY_A))
		{
			cout << "Key A pressed" << endl;
		}

        if (window.isMouseButtonPressed(GLFW_MOUSE_BUTTON_LEFT))
        {
            cout << "Left Mouse pressed" << endl;
        }
        */
        if (window.isMouseButtonPressed(GLFW_MOUSE_BUTTON_LEFT))
        {
            double x,y;
            window.getMousePosition(x, y);
            cout << "x: " << x << "\ty: " << y << endl;
        }
        glBegin(GL_QUADS);
        glVertex2f(-0.5f, -0.5f);
        glVertex2f(-0.5f,  0.5f);
        glVertex2f( 0.5f,  0.5f);
        glVertex2f( 0.5f, -0.5f);
        glEnd();

        glDrawArrays(GL_ARRAY_BUFFER, 0, 6);
        window.update();
    }
    return 0;
}
