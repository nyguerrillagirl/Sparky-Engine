#include <iostream>
#include "UnitTest++.h"
using namespace std;

int main()
{
    return UnitTest::RunAllTests();
}

